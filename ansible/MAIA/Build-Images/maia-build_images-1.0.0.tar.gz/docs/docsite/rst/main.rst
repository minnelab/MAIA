Build Images
============

The MAIA Build-Images Ansible collection provides automation for building and pushing Docker images for the MAIA platform components to container registries (Docker Hub, GitHub Container Registry, or private registries).

Requirements
------------

Before running the playbooks, ensure you have:

- Docker installed and configured on the build host
- Git credentials (username and token/password) for accessing MAIA repositories
- Registry credentials for pushing images (Docker Hub, GitHub, or private registry)
- The MAIA toolkit installed with the ``MAIA_build_images`` command available
- A properly configured environment with ``env.json`` and cluster configuration files

Required Variables
------------------

The build_images role requires the following variables:

- **config_folder**: Directory containing ``env.json``, cluster configuration YAML, and registry credentials JSON
- **cluster_name**: Name of the cluster configuration file (without .yaml extension, e.g., ``maia-dev``)
- **GIT_USERNAME**: Git username for accessing MAIA source repositories
- **GIT_TOKEN**: Git token or password for authentication
- **registry_base**: Docker registry base URL (e.g., ``https://index.docker.io/v1/`` for Docker Hub or ``ghcr.io`` for GitHub)
- **registry_path**: Registry organization/path (e.g., ``maiacloudai`` for Docker Hub or ``/minnelab`` for GitHub)
- **credentials_json_filename**: Name of the registry credentials JSON file (e.g., ``dockerhub-registry-credentials.json`` or ``github-registry-credentials.json``)
- **maia_project_id**: MAIA project identifier for the registry (e.g., ``maia-image-dockerhub`` or ``maia-image-github``)

Optional Variables
------------------

See ``roles/build_images/defaults/main.yml`` for additional optional variables including:

- Repository URLs and branches
- Image tags and versions
- Additional build options

Configuration Files
-------------------

Registry Credentials
~~~~~~~~~~~~~~~~~~~~

The registry credentials file (``<credentials_json_filename>``) should be placed in the ``config_folder`` and contain:

.. code-block:: json

    {
      "username": "registry-username",
      "password": "registry-password-or-token"
    }

For Docker Hub, use your Docker Hub username and an access token.
For GitHub Container Registry, use your GitHub username and a personal access token with ``write:packages`` scope.

Environment Configuration
~~~~~~~~~~~~~~~~~~~~~~~~~

The ``env.json`` file in the ``config_folder`` should contain necessary environment variables for the MAIA build process.

Cluster Configuration
~~~~~~~~~~~~~~~~~~~~~

The cluster configuration YAML (``<cluster_name>.yaml``) in the ``config_folder`` should contain cluster-specific settings.

Build Process
-------------

The build_images role executes the ``MAIA_build_images`` helper script which:

1. Clones MAIA source repositories using the provided Git credentials
2. Builds Docker images for MAIA components
3. Tags images with appropriate versions and registry paths
4. Pushes images to the specified container registry
5. Updates configuration files with new image references

The script uses values previously exported and configuration files in the ``config_folder`` to determine what to build and where to push images.

Inventory
=========

The playbook runs on ``localhost`` and does not require a complex inventory. It can be executed with a simple inventory file:

.. code-block:: ini

    [local]
    localhost ansible_connection=local

Or directly without an inventory file by targeting localhost.

Usage
=====

See the Example section for complete usage examples with different registry configurations.
