# Ansible Collection - MAIA.Build_Images

Documentation for the MAIA.Build_Images Ansible collection, which provides roles and playbooks for building and pushing Docker images for MAIA (Medical AI Assistant) platform components to container registries.

## Requirements

The following packages and tools are required before using this collection:

**Python packages:**
```bash
pip install maia-toolkit ansible
```

### Minimum Hardware Requirements

To successfully build MAIA images, your build host should meet at least the following specifications:

- **Memory:** 8 GB RAM
- **CPU:** 4 CPU cores
- **Disk:** 50 GB available storage (for Docker images and build cache)
- **Network:** Stable internet connection for pulling base images and pushing to registries

**Operating System:**  
MAIA image building has been tested on Ubuntu 22.04 and 24.04 LTS.

> **Note:**  
> These requirements are for building MAIA platform images. Building time may vary depending on the number of images and your internet connection speed.

## Installation

To install the MAIA.Build_Images collection, run the following command:
```bash
ansible-galaxy collection install MAIA.Build_Images
```

Or install from source:
```bash
cd ansible/MAIA/Build-Images
ansible-galaxy collection build
ansible-galaxy collection install maia-build_images-1.0.0.tar.gz
```

## Quick Start

### 1. Prepare Configuration

Before building images, you need:

- A configuration folder containing `env.json` and cluster configuration files
- Git credentials (username and token) for accessing MAIA repositories
- Registry credentials for pushing images

**Create registry credentials file:**

For Docker Hub (`dockerhub-registry-credentials.json`):
```json
{
  "username": "your-dockerhub-username",
  "password": "your-dockerhub-token"
}
```

For GitHub Container Registry (`github-registry-credentials.json`):
```json
{
  "username": "your-github-username",
  "password": "your-github-token"
}
```

### 2. Run the Build Playbook

**For Docker Hub:**
```bash
ansible-playbook playbooks/build_images.yaml \
  -e config_folder=/path/to/config \
  -e cluster_name=maia-cluster \
  -e GIT_USERNAME=your-git-username \
  -e GIT_TOKEN=your-git-token \
  -e registry_base=https://index.docker.io/v1/ \
  -e registry_path=maiacloudai \
  -e credentials_json_filename=dockerhub-registry-credentials.json \
  -e maia_project_id=maia-image-dockerhub
```

**For GitHub Container Registry:**
```bash
ansible-playbook playbooks/build_images.yaml \
  -e config_folder=/path/to/config \
  -e cluster_name=maia-cluster \
  -e GIT_USERNAME=your-git-username \
  -e GIT_TOKEN=your-git-token \
  -e registry_base=ghcr.io \
  -e registry_path=/minnelab \
  -e credentials_json_filename=github-registry-credentials.json \
  -e maia_project_id=maia-image-github
```

## Required Variables

The following variables must be provided when running the build_images playbook:

- **config_folder**: Directory containing `env.json`, cluster config, and registry credentials
- **cluster_name**: Name of the cluster configuration file (without .yaml extension)
- **GIT_USERNAME**: Git username for accessing MAIA repositories
- **GIT_TOKEN**: Git token or password for authentication
- **registry_base**: Registry base URL
  - Docker Hub: `https://index.docker.io/v1/`
  - GitHub: `ghcr.io`
  - Private registry: `https://harbor.example.com`
- **registry_path**: Registry organization or path
  - Docker Hub: `maiacloudai`
  - GitHub: `/minnelab`
  - Private: `/your-project`
- **credentials_json_filename**: Name of the registry credentials JSON file in config_folder
- **maia_project_id**: MAIA project identifier for the registry

## Optional Variables

See `roles/build_images/defaults/main.yml` for additional configurable variables including:

- Repository URLs and branches
- Image tags and versions
- Build-time options

## Using Environment Variables

Instead of passing credentials on the command line, you can use environment variables:

```bash
export GIT_USERNAME=your-username
export GIT_TOKEN=your-token

ansible-playbook playbooks/build_images.yaml \
  -e config_folder=/path/to/config \
  -e cluster_name=maia-cluster \
  -e GIT_USERNAME="{{ lookup('env', 'GIT_USERNAME') }}" \
  -e GIT_TOKEN="{{ lookup('env', 'GIT_TOKEN') }}" \
  -e registry_base=https://index.docker.io/v1/ \
  -e registry_path=maiacloudai \
  -e credentials_json_filename=dockerhub-registry-credentials.json \
  -e maia_project_id=maia-image-dockerhub
```

## Using the Role Directly

You can also use the `build_images` role in your own playbooks:

```yaml
---
- name: Build MAIA images
  hosts: localhost
  vars:
    config_folder: /opt/maia/config
    cluster_name: maia-cluster
    GIT_USERNAME: "{{ lookup('env', 'GIT_USERNAME') }}"
    GIT_TOKEN: "{{ lookup('env', 'GIT_TOKEN') }}"
    registry_base: https://index.docker.io/v1/
    registry_path: maiacloudai
    credentials_json_filename: dockerhub-registry-credentials.json
    maia_project_id: maia-image-dockerhub
  vars_files:
    - "{{ config_folder }}/env.json"
    - "{{ config_folder }}/{{ cluster_name }}.yaml"
  roles:
    - maia.build_images.build_images
```

## Supported Registries

The collection supports building and pushing images to:

- **Docker Hub** (`https://index.docker.io/v1/`)
- **GitHub Container Registry** (`ghcr.io`)
- **Private registries** (Harbor, GitLab Registry, etc.)

## Troubleshooting

### Common Issues

**1. Authentication failures:**
- Verify Git credentials have access to MAIA repositories
- Ensure registry credentials are correct
- Check that tokens have not expired and have appropriate permissions

**2. Build failures:**
- Ensure Docker is running: `systemctl status docker`
- Check disk space: `df -h`
- Verify `MAIA_build_images` command is available: `which MAIA_build_images`

**3. Push failures:**
- Confirm network connectivity to the registry
- Verify registry path and project exist
- Check that you have push permissions

### Verbose Mode

For detailed output during the build process:

```bash
ansible-playbook -vvv playbooks/build_images.yaml (...)
```

## Documentation

For detailed documentation, see:

- [Main Documentation](docs/docsite/rst/main.rst) - Requirements, configuration, and build process
- [Usage Examples](docs/docsite/rst/example.rst) - Complete examples for different registries

<!-- DOCS-START -->
<!-- DOCS-END -->

<!-- DOCS-EXAMPLE-START -->
<!-- DOCS-EXAMPLE-END -->

## Contributing

For issues, feature requests, or contributions, please visit the [MAIA GitHub repository](https://github.com/minnelab/MAIA).

## License

This collection is licensed under GPL-3.0-only. See the LICENSE file for details.

## Authors

- Simone Bendazzoli <simben@kth.se>
